<?php
namespace Home\Controller;
use Think\Controller;

class HeaderController extends Controller{
	function header(){	
		$this -> display();
	}
}